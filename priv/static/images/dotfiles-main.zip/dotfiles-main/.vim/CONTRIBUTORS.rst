.VIMRC Contributors
===================

+ Roman Mogilatov
+ Sergii [boonya] Buinytskyi
+ Alexander Antukh
+ Cyril Danilevski
