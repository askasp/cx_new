# key_layout

Display the current keyboard layout using setxkbmap.

![](key_layout.png)

![](key_layout_variant.png)

# Installation

Use the following in your i3blocks config:

```ini
[key_layout]
command=$SCRIPT_DIR/key_layout
label=Layout
interval=30
```
