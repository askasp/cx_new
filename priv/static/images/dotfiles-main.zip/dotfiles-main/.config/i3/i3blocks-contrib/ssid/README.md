# ssid

Show the SSID of the current wifi connection.
If no instance is specified, wlan0 is used.

Dependencies: `iw`

# Config

```
[ssid]
command=$SCRIPT_DIR/ssid
#INTERFACE=wlan0
interval=60
```
